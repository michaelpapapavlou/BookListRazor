﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SparkAuto.Utility
{
    public static class SD
    {
        public const string AdminEndUser = "Admin";
        public const string CustomerEndUser = "Customer";
        public const int PaginationUsersPageSize = 2;
    }
}
